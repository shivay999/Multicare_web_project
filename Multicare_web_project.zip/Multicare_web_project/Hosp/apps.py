from django.apps import AppConfig


class HospConfig(AppConfig):
    name = 'Hosp'
